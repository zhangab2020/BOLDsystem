# 按科属种提取坐标并作图
# 当然前面查询基本信息和序列的时候也可以按照科属水平去查找，可自行变通

rm(list = ls())

library(bold)
library(openxlsx)
library(tidyr)
library(beepr)


# 科-----------------
a <- bold_specimens(taxon='Nolidae') #瘤蛾科测试
a <- bold_specimens(taxon='Nolidae',geo='China') #限制样本采集地为中国，不限制默认为全世界
beepr::beep(sound = "mario")#因为BOLD比较慢（相比于GBIF），这边设置一个程序运行完的提示音
Location <- unique(a[c(22,47,48)]) # 47,48是纬度和经度，去重可能会有一行是空值
good <- complete.cases(Location) #找到非空值,这里都是逻辑值
Location_family <- Location[good, ] #提取非空值所有行，就是所有非重复坐标
# 保存数据
#如果物种名一栏是空的，表明只定到了属，没定到种，可根据分析目的合理筛选
write.xlsx(Location_family,'Location_family.xlsx')
# 作图
# 请使用【物种批量出图.R】脚本作图

# 属-----------------
b <- bold_specimens(taxon='Meganola') #瘤蛾科 Meganola属 测试
b <- bold_specimens(taxon='Meganola',geo='China')
beepr::beep(sound = "mario")
Location <- unique(b[c(22,47,48)]) # 47,48是纬度和经度，去重可能会有一行是空值
good <- complete.cases(Location) #找到非空值,这里都是逻辑值
Location_genus <- Location[good, ] #提取非空值所有行，就是所有非重复坐标
# 保存数据
#如果属名一栏是空的，表明只定到了科，没定到属，可根据分析目的合理筛选
write.xlsx(Location_genus,'Location_genus.xlsx')
# 作图
# 请使用【物种批量出图.R】脚本作图

# 种-----------------
# 如果是一个物种可以向上面科属类似，把“taxon=”后面的内容换成某个物种就行
# 但是一般我们需要批量查询多个物种，可以采用下面的循环
# species_list.xlsx 存入需要问询的物种，格式参考实例文件
species <- as.vector(unlist(read.xlsx('species_list.xlsx',colNames = F)))

da_Location <- data.frame()#新建一个空数据框，用于分别存放循环中产生的坐标数据

for(i in species){
  # 如果问询的物种在库内没有记录，则a为NA  
  a <- bold_seqspec(taxon = i) # bold_specimens返回的是一个data.frame
  # 一般比较关心的是这个物种的GenBank编号、分类信息、坐标信息、图片网址信息。
  if(is.na(a)){next}else{
    # 坐标信息
    Location <- unique(a[c(22,47,48)]) # 47,48是纬度和经度，去重可能会有一行是空值
    good <- complete.cases(Location) #找到非空值
    Location <- Location[good, ] #提取非空值所有行，就是所有非重复坐标
    da_Location <- rbind(da_Location,Location)

    print(i)  # 看看运行到第几个了（对于异常终止比较有用）
  }
}
beepr::beep(8) #因为BOLD比较慢（相比于GBIF），这边设置一个程序运行完的提示音

# 保存数据
write.xlsx(da_Location,'Location_sp.xlsx')
