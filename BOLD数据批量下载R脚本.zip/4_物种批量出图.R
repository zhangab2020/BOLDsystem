# 不同物种批量打点出地图

rm(list = ls()) #清除环境变量

library(openxlsx)
library(ggplot2)
library(tidyverse)
library(sf)
library(maptools)
library(ggspatial)
library(cowplot)
library(purrr)


# 世界循环作图:定义函数+purrr-------------------------------------------
input <- read.xlsx('去重后-4.xlsx')

world <- map_data("world")
# world <- world[world$region != "Antarctica",] # 剔除南极洲

# 定义作图函数（逐个保存）---------------------------------------
plot_world <- function(x) {
  df <- subset(input,species_name == x)
  ggplot(world)+
    geom_polygon(aes(x=long,y=lat,group=group),fill='white',colour='black')+
    coord_quickmap()+ #为地图设置合适的纵横比
    geom_point(data = df,aes(lon,lat),
               shape=16,colour='red',size=1)+
    ggtitle(paste('The worldwide distribution of',x))+
    theme(plot.title = element_text(hjust = .5),panel.grid = element_blank())
  filename <- paste('World_',x,'.pdf')
  ggsave(filename,width = 7, height = 5)
}
# 利用purrr的map函数循环出图，利用cowplot::plot_grid()函数排列图
sp <- as.vector(unlist(unique(input[1])))
purrr::map(sp, plot_world) #批量绘图,默认的是7*7的尺寸




