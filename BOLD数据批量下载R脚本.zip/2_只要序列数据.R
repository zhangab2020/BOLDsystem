# 只获取序列数据

rm(list = ls())

library(bold)
library(openxlsx)
library(tidyr)


# 某个物种的所有序列---------------------------------------------------------------------------

species = 'Papilio machaon' #你需要问询的物种,这边以金凤蝶为例
a <- bold_seq(taxon = species) # bold_seq返回的是一个包含4个list(id name gene sequence)的list
length(a) # a包含的list的个数，下面一行命令会用到
b <- as.data.frame(matrix(unlist(a), nrow=length(a), byrow=T)) #nrow是根据a中包含的list的个数定的
# 1和3列是重复的，把第一列删除
b <- b[,-1]
# 把每行合并起来，新生成一列放在b后面，方便后续的使用
names(b) <- c('name','gene','sequence') # 先把数据框重命名
c <- tidyr::unite(b,'name_gene',name,gene) #remove = FALSE 参数则不会删除原来的数据列
names(c) <- c('ID','sequence') # 重命名一下列名
d <- tidyr::unite(c,'ID,sequence',ID,sequence,sep = ",")#这边用,隔开,方便后续按照,替换为换行符做成.fasta格式
e <- data.frame(matrix(rep('>',length(a)), nrow=length(a), byrow=T))
f <- cbind(e,d)
names(f) <- c('start','ID_sequence')
g <- tidyr::unite(f,'start,ID_sequence',start,ID_sequence,sep = "")#起到的效果就是在d的每一行开头添加一个>
names(g) <- c('sequences')
filename <- paste0('2_','某个物种的所有序列_',species,".fas")
out <- write.table(g,filename,row.names = F,col.names = F)

# 接下来需要在文本编辑器中把所有引号都替换为空，把英文的逗号替换为换行符
# 注意：物种拉丁名中间是空格，要注意。

# 多个物种的所有序列---------------------------------------------------------------------------

rm(list = ls())
species <- as.vector(unlist(read.xlsx('species_list.xlsx',colNames = F)))
da <- data.frame()   #新建一个空数据框，用于存放循环中产生的da
for(i in species) {
  species = i #你需要问询的物种
  a <- bold_seq(taxon = species) # bold_seq返回的是一个包含4个list(id name gene sequence)的list
  length(a) # a包含的list的个数，下面一行命令会用到
  if(length(a)==0){next}else{ #如果需要问询的物种没有序列，则length(a)=0，则跳过该物种
    b <- as.data.frame(matrix(unlist(a), nrow=length(a), byrow=T)) #nrow是根据a中包含的list的个数定的
    # 1和3列是重复的，把第一列删除
    b <- b[,-1]
    # 把每行合并起来，新生成一列放在b后面，方便后续的使用
    names(b) <- c('name','gene','sequence') # 先把数据框重命名
    c <- tidyr::unite(b,'name_gene',name,gene) #remove = FALSE 参数则不会删除原来的数据列
    names(c) <- c('ID','sequence') # 重命名一下列名
    d <- tidyr::unite(c,'ID,sequence',ID,sequence,sep = ",")#这边用,隔开,方便后续按照,替换为换行符做成.fasta格式
    e <- data.frame(matrix(rep('>',length(a)), nrow=length(a), byrow=T))
    f <- cbind(e,d)
    names(f) <- c('start','ID_sequence')
    g <- tidyr::unite(f,'start,ID_sequence',start,ID_sequence,sep = "")#起到的效果就是在d的每一行开头添加一个>
    names(g) <- c('sequences')
    da <- rbind(da,g)
    }
}
out <- write.table(da,'2_多个物种所有条码.fas',row.names = F,col.names = F)
# 接下来需要在文本编辑器中把所有引号都替换为空(就删删除)，把英文的逗号替换为换行符
# 注意：物种拉丁名中间是空格。
# 如果需要特定属的，只需要把物种名换成属名就行,那每一个小的list就是一个物种。

# 多个物种各选1条条码------------------------------------------------------------------

# 某个物种的第一条序列（也就是选一条序列来代表这个物种）,当然输入肯定不只是一个物种
# 那就在上面代码的基础上
rm(list = ls())
species <- as.vector(unlist(read.xlsx('species_list.xlsx',colNames = F)))
da <- data.frame()   #新建一个空数据框，用于存放循环中产生的da
for(i in species) {
  species = i #你需要问询的物种
  s <- bold_seq(taxon = species)
  if(length(s)==0){next}else{ #如果需要问询的物种没有序列，则length(s)=0，则跳过该物种
    a <- bold_seq(taxon = species)[[1]] # bold_seq返回的是一个包含4个list(id name gene sequence)的list
    b <- as.data.frame(matrix(unlist(a), nrow=1, byrow=T)) 
    b <- b[,-1]
    # 把每行合并起来，新生成一列放在b后面，方便后续的使用
    names(b) <- c('name','gene','sequence') # 先把数据框重命名
    c <- tidyr::unite(b,'name_gene',name,gene) #remove = FALSE 参数则不会删除原来的数据列
    names(c) <- c('ID','sequence') # 重命名一下列名
    d <- tidyr::unite(c,'ID,sequence',ID,sequence,sep = ",")#这边用,隔开,方便后续按照,替换为换行符做成.fasta格式
    e <- data.frame(matrix(rep('>',length(a)), nrow=length(a), byrow=T))
    f <- cbind(e,d)
    names(f) <- c('start','ID_sequence')
    g <- tidyr::unite(f,'start,ID_sequence',start,ID_sequence,sep = "")#起到的效果就是在d的每一行开头添加一个>
    names(g) <- c('sequences')
    da <- rbind(da,g)
    }
}
da <- unique(da)
out <- write.table(da,'2_多个物种每种1条条码.fas',row.names = F,col.names = F)
# 接下来需要在文本编辑器中把所有引号都替换为空，把英文的逗号替换为换行符
# 注意：物种拉丁名中间是空格，要注意。

# 多个物种挑选固定数量的条码------------------------------------------------------------------
rm(list = ls())
species <- as.vector(unlist(read.xlsx('species_list.xlsx',colNames = F)))
da <- data.frame()   #新建一个空数据框，用于存放循环中产生的da
n = 3 #这边是你需要的每个物种重复条码的数量，这边以3为例
for(i in species) {
  species = i #你需要问询的物种
  s <- bold_seq(taxon = species) # bold_seq返回的是一个包含4个list(id name gene sequence)的list
  length(s) # a包含的list的个数，下面一行命令会用到
  if(length(s)==0){next      #如果需要问询的物种无条码,则跳过
    }else if(length(s) < n){ #如果需要问询的物种一共的条码数都不到n,则全取
    a <- bold_seq(taxon = species) # bold_seq返回的是一个包含4个list(id name gene sequence)的list
    length(a) # a包含的list的个数，下面一行命令会用到
    b <- as.data.frame(matrix(unlist(a), nrow=length(a), byrow=T)) #nrow是根据a中包含的list的个数定的
    # 1和3列是重复的，把第一列删除
    b <- b[,-1]
    # 把每行合并起来，新生成一列放在b后面，方便后续的使用
    names(b) <- c('name','gene','sequence') # 先把数据框重命名
    c <- tidyr::unite(b,'name_gene',name,gene) #remove = FALSE 参数则不会删除原来的数据列
    names(c) <- c('ID','sequence') # 重命名一下列名
    d <- tidyr::unite(c,'ID,sequence',ID,sequence,sep = ",")#这边用,隔开,方便后续按照,替换为换行符做成.fasta格式
    e <- data.frame(matrix(rep('>',length(a)), nrow=length(a), byrow=T))
    f <- cbind(e,d)
    names(f) <- c('start','ID_sequence')
    g <- tidyr::unite(f,'start,ID_sequence',start,ID_sequence,sep = "")#起到的效果就是在d的每一行开头添加一个>
    names(g) <- c('sequences')
    da <- rbind(da,g)
    }else{ 
    a <- bold_seq(taxon = species)[c(1:n)]# list取子集
    b <- as.data.frame(matrix(unlist(a), nrow=n, byrow=T)) 
    # 1和3列是重复的，把第一列删除
    b <- b[,-1]
    # 把每行合并起来，新生成一列放在b后面，方便后续的使用
    names(b) <- c('name','gene','sequence') # 先把数据框重命名
    c <- tidyr::unite(b,'name_gene',name,gene) #remove = FALSE 参数则不会删除原来的数据列
    names(c) <- c('ID','sequence') # 重命名一下列名
    d <- tidyr::unite(c,'ID,sequence',ID,sequence,sep = ",")#这边用,隔开,方便后续按照,替换为换行符做成.fasta格式
    e <- data.frame(matrix(rep('>',length(a)), nrow=length(a), byrow=T))
    f <- cbind(e,d)
    names(f) <- c('start','ID_sequence')
    g <- tidyr::unite(f,'start,ID_sequence',start,ID_sequence,sep = "")#起到的效果就是在d的每一行开头添加一个>
    names(g) <- c('sequences')
    da <- rbind(da,g)
    }
}
out <- write.table(da,'2_多个物种每种固定数量条码.fas',row.names = F,col.names = F)
