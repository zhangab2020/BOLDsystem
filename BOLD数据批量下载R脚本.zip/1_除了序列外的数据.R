# 不管是只要序列还是只要其他信息，都先把这些信息全部问询下来，然后再挑选
# 反正速度都很慢
# 不管是一个物种还是多个物种都把它放到 species_list.xlsx 内用于问询

rm(list = ls()) #清楚全局环境变量

# 载入相关R包

library(bold)
library(openxlsx)
library(tidyr)
library(beepr)

# 数据导入
species <- as.vector(unlist(read.xlsx('species_list.xlsx',colNames = F)))

# 循环模式----------------------------------------------------------------------------
da_GenBank_ID <- data.frame() #新建一个空数据框，用于分别存放循环中产生的数据
da_Taxon <- data.frame()      #存放分类信息
da_Location <- data.frame()   #存放分布数据
da_Image_urls <- data.frame() #存放图片的url

for(i in species){
  # 如果问询的物种在库内没有记录，则a为NA  
  a <- bold_seqspec(taxon = i) # bold_specimens返回的是一个data.frame
  # 一般比较关心的是这个物种的GenBank编号、分类信息、坐标信息、图片网址信息。
  if(is.na(a)){next}else{
    # GenBank编号
    GenBank_ID <- subset(a,institution_storing == 'Mined from GenBank, NCBI',
                         select = c(species_name,sampleid,institution_storing))
    da_GenBank_ID <- rbind(da_GenBank_ID,GenBank_ID)
    # 分类信息
    Taxon <- unique(a[c(16,18,20,22)]) #16,18,20,22对应的列是科,亚科,属,种,后面还有亚种,看需要
    da_Taxon <- rbind(da_Taxon,Taxon)
    # 坐标信息
    Location <- unique(a[c(22,47,48)]) # 47,48是纬度和经度，去重可能会有一行是空值
    good <- complete.cases(Location) #找到非空值
    Location <- Location[good, ] #提取非空值所有行，就是所有非重复坐标
    da_Location <- rbind(da_Location,Location)
    # 图片信息
    Image_urls <- subset(a,image_urls != "",select = c(species_name,image_urls))
    da_Image_urls <- rbind(da_Image_urls,Image_urls)
    print(i)  # 看看运行到第几个了（对于异常终止比较有用）
  }
}
beepr::beep(8) #因为BOLD比较慢（相比于GBIF），这边设置一个程序运行完的提示音

# 接下来就是保存你需要的数据内容
write.xlsx(da_GenBank_ID,'da_GenBank_ID.xlsx')
write.xlsx(da_Taxon,'da_Taxon.xlsx')
write.xlsx(da_Location,'da_Location.xlsx')
write.xlsx(da_Image_urls,'da_Image_urls.xlsx')

# 非循环模式-----------------------------------------------------------------------------

# 如果问询的物种在库内没有记录，则a为NA  
a <- bold_seqspec(taxon = species) # bold_specimens返回的是一个data.frame
beepr::beep(8) #因为BOLD比较慢（相比于GBIF），这边设置一个程序运行完的提示音

# 一般比较关心的是这个物种的GenBank编号、分类信息、坐标信息、图片网址信息。需要哪个就运行哪个。

# GenBank编号
GenBank_ID <- subset(a,institution_storing == 'Mined from GenBank, NCBI',
                     select = c(species_name,sampleid,institution_storing))

# 分类信息
Taxon <- unique(a[c(16,18,20,22)]) #16,18,20,22对应的列是科,亚科,属,种,后面还有亚种,看需要

# 坐标信息
Location <- unique(a[c(22,47,48)]) # 47,48是纬度和经度，去重可能会有一行是空值
good <- complete.cases(Location) #找到非空值
Location <- Location[good, ] #提取非空值所有行，就是所有非重复坐标

# 图片信息
Image_urls <- subset(a,image_urls != "",select = c(species_name,image_urls))

# 接下来就是保存你需要的数据内容
write.xlsx(da_GenBank_ID,'da_GenBank_ID.xlsx')
write.xlsx(da_Taxon,'da_Taxon.xlsx')
write.xlsx(da_Location,'da_Location.xlsx')
write.xlsx(da_Image_urls,'da_Image_urls.xlsx')

  


